# This will print the current Version


def printVersion():
    raise SystemExit("pdrozd-ssg release version 1.0.10")
